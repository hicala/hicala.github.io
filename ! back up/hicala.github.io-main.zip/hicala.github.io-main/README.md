# Hila Calderon. 
## Data Scientist and Geospatial Data Engineer
----------


### Portfolio Site under construction

![Construction Scene](https://raw.githubusercontent.com/ugurcandede/Under-Construction/master/construction-scene/Capture.PNG)


I am working day and night to have it ready by adding near 15 year of experience in a readable digital format
----------

Feel free to connect with me on [LinkedIn](https://www.linkedin.com/in/hilariocalderon/) or get in touch if you want to have a technical debate about my topics of research, discuss collaboration, consulting or join working or reserach opportunities.

You can find a contact form on the homepage, or send directly an <a href="mailto:calderon.hila@gmail.com">Email</a>. 

Thank you for reading!

HC

